OST_WindyLines Cross Platform Package

Contents:
- macOS/OST_WindyLines.plugin
- Windows/... (aex と任意ファイル)

Install (macOS):
1. Copy OST_WindyLines.plugin to Adobe MediaCore plug-ins folder.

Install (Windows):
1. Windows フォルダ内の aex を Adobe plug-ins folder にコピーしてください。

Build config: Release
Created at: Sat Feb 21 16:20:01 JST 2026
